Welcome to the Diva addons to OpenSim!

This projects hosts the Wifi web app as well as assorted modules
that enable power uses of OpenSim.
