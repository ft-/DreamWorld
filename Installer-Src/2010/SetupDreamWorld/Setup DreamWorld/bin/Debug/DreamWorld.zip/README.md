A  easy and complete installer for standalone Opensimulator for Windows.

OpenSimulator is normally not easy for new people. This automates away  all setup, and a mesh-compliant viewer, Onlook is installed and pre-set with grid info, ready to go.

Upon completion of  setup, the program displays a Start button which boots up MySQL, Apache, Opensim, the Wifi Web Interface and the viewer, ready to log in.  

A third click will close everything down.

