License:

The DreamWorld installer program is Copyright 2016  by Fred Beckhusen

Redistribution and use in binary and source form is permitted provided that the following conditions are met:

    * Redistributions must reproduce the above copyright       notices, this list of conditions and the following disclaimer in the documentation and/or other materials provided with thed istribution.
    * Neither the name of Outworldz nor the names of individual contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE DEVELOPERS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY DIRECT,INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

IN NO EVENT SHALL DEVELOPERS BE REQUIRED TO PROVIDE DOCUMENTATION BEYOND THAT INCLUDED WITH THE SOFTWARE AND UNDER NO CIRCUNSTANCES SHOULD  DEVELOPERS BE SOLICITED FREE TECHNICAL SUPPORT.


All other licenses in Opensimulator and Onlook Viewer are by their respective owners.

This product is made possible by the work of the entire OpenSimulator development team, and specifically Crista Lopes (Diva Canto) for her "Diva Distro" of OpenSim.

For licensing information, please see licenses in the Apache, Opensim, mowes, and php5 folders. Additional licenses, such as for MySQL, may also apply.

